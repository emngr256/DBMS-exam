import com.mongodb.client.*;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import java.sql.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Main {
    private static final String SQL_URL = "jdbc:postgresql://localhost:5432/food_delivery_db";
    private static final String SQL_USER = "postgres";
    private static final String SQL_PASS = "1234";
    private static final String MONGO_URI = "mongodb+srv://alan27945_db_user:1234@cluster0.o586osv.mongodb.net/?appName=Cluster0";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try (Connection sqlConn = DriverManager.getConnection(SQL_URL, SQL_USER, SQL_PASS);
             MongoClient mongoClient = MongoClients.create(MONGO_URI)) {

            MongoDatabase mongoDb = mongoClient.getDatabase("food_delivery_db");
            MongoCollection<Document> mongoUsers = mongoDb.getCollection("users");

            while (true) {
                System.out.println("\n===== DATABASE MANAGEMENT SYSTEM =====");
                System.out.println("1. View All Users (Full Info)");
                System.out.println("2. Create New User & Address");
                System.out.println("3. Update Existing User & Address");
                System.out.println("4. Delete User by ID");
                System.out.println("5. Exit");
                System.out.print("Action: ");

                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1: // READ (JOIN SQL + MONGO)
                        String joinSql = "SELECT u.*, a.street, a.city FROM users u LEFT JOIN addresses a ON u.user_id = a.user_id ORDER BY u.user_id";
                        ResultSet rs = sqlConn.createStatement().executeQuery(joinSql);
                        System.out.println("\n--- LIST OF USERS ---");
                        while (rs.next()) {
                            int id = rs.getInt("user_id");
                            System.out.println("ID: " + id + " | Name: " + rs.getString("name") + " | Phone: " + rs.getString("phone"));
                            System.out.println("   Address: " + rs.getString("street") + ", " + rs.getString("city"));
                        }
                        break;

                    case 2: // CREATE
                        System.out.print("Name: "); String n = scanner.nextLine();
                        System.out.print("Email: "); String e = scanner.nextLine();
                        System.out.print("Phone: "); String p = scanner.nextLine();
                        System.out.print("Street: "); String st = scanner.nextLine();
                        System.out.print("City: "); String ct = scanner.nextLine();

                        // 1. Вставка в Postgres (Users)
                        int newId = -1;
                        PreparedStatement p1 = sqlConn.prepareStatement("INSERT INTO users (name, email, phone) VALUES (?, ?, ?) RETURNING user_id");
                        p1.setString(1, n); p1.setString(2, e); p1.setString(3, p);
                        ResultSet rs1 = p1.executeQuery();
                        if (rs1.next()) newId = rs1.getInt(1);

                        // 2. Вставка в Postgres (Addresses)
                        PreparedStatement p2 = sqlConn.prepareStatement("INSERT INTO addresses (user_id, street, city) VALUES (?, ?, ?)");
                        p2.setInt(1, newId); p2.setString(2, st); p2.setString(3, ct);
                        p2.executeUpdate();

                        // 3. Вставка в MongoDB
                        Document mAddr = new Document("street", st).append("city", ct);
                        List<Document> mList = new ArrayList<>(); mList.add(mAddr);
                        Document mUser = new Document("user_id", newId).append("name", n).append("phone", p).append("addresses", mList);
                        mongoUsers.insertOne(mUser);

                        System.out.println("SUCCESS: Created ID " + newId + " in both DBs.");
                        break;

                    case 3: // UPDATE (Изменение данных)
                        System.out.print("Enter ID to change: "); int upId = scanner.nextInt(); scanner.nextLine();
                        System.out.print("New Name: "); String un = scanner.nextLine();
                        System.out.print("New Phone: "); String up = scanner.nextLine();
                        System.out.print("New Street: "); String us = scanner.nextLine();

                        // Update SQL Users
                        PreparedStatement u1 = sqlConn.prepareStatement("UPDATE users SET name=?, phone=? WHERE user_id=?");
                        u1.setString(1, un); u1.setString(2, up); u1.setInt(3, upId); u1.executeUpdate();

                        // Update SQL Addresses
                        PreparedStatement u2 = sqlConn.prepareStatement("UPDATE addresses SET street=? WHERE user_id=?");
                        u2.setString(1, us); u2.setInt(2, upId); u2.executeUpdate();

                        // Update MongoDB
                        mongoUsers.updateOne(Filters.eq("user_id", upId),
                                Updates.combine(
                                        Updates.set("name", un),
                                        Updates.set("phone", up),
                                        Updates.set("addresses.0.street", us)
                                ));
                        System.out.println("SUCCESS: Updated successfully.");
                        break;

                    case 4: // DELETE
                        System.out.print("Enter ID: "); int dId = scanner.nextInt();
                        sqlConn.prepareStatement("DELETE FROM users WHERE user_id = " + dId).executeUpdate();
                        mongoUsers.deleteOne(Filters.eq("user_id", dId));
                        System.out.println("Deleted.");
                        break;

                    case 5: return;
                }
            }
        } catch (Exception ex) {
            System.err.println("CRITICAL ERROR: " + ex.getMessage());
            ex.printStackTrace(); // Это покажет, почему не добавляется в Postgres
        }
    }
}